#pragma once

#include <cstdint>
#include <string>
#include <memory>

#include "plugify_export.h"

namespace glz {
	template<typename T>
	struct meta;
}

namespace plugify {
	class Method;

	// EnumValue Class
	class PLUGIFY_API EnumValue {
	    struct Impl;
	public:
	    EnumValue();
	    ~EnumValue();
	    EnumValue(const EnumValue& other);
	    EnumValue(EnumValue&& other) noexcept;
	    EnumValue& operator=(const EnumValue& other);
	    EnumValue& operator=(EnumValue&& other) noexcept;

	    // Getters
	    [[nodiscard]] std::string_view GetName() const noexcept;
	    [[nodiscard]] int64_t GetValue() const noexcept;

	    // Setters (pass by value and move)
	    void SetName(std::string_view name) noexcept;
	    void SetValue(int64_t value) noexcept;


		[[nodiscard]] bool operator==(const EnumValue& other) const noexcept;
		[[nodiscard]] auto operator<=>(const EnumValue& other) const noexcept;

	private:
	    friend struct glz::meta<EnumValue>;
		//friend struct std::hash<EnumValue>;
	    std::unique_ptr<Impl> _impl;
	};
}
