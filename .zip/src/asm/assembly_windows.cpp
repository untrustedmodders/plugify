#if PLUGIFY_PLATFORM_WINDOWS

#include "plugify/asm/assembly.hpp"

#include "defer.hpp"
#include "os.h"

std::string_view kExecutableCode = ".text";

#if PLUGIFY_ARCH_BITS == 64
	const WORD PE_FILE_MACHINE = IMAGE_FILE_MACHINE_AMD64;
	const WORD PE_NT_OPTIONAL_HDR_MAGIC = IMAGE_NT_OPTIONAL_HDR64_MAGIC;
#else
	const WORD PE_FILE_MACHINE = IMAGE_FILE_MACHINE_I386;
	const WORD PE_NT_OPTIONAL_HDR_MAGIC = IMAGE_NT_OPTIONAL_HDR32_MAGIC;
#endif // PLUGIFY_ARCH_BITS

using namespace plugify;

static std::string GetErrorMessage() {
	DWORD dwErrorCode = ::GetLastError();
	if (dwErrorCode == 0) {
		return {}; // No error message has been recorded
	}

	LPSTR messageBuffer = NULL;
	const DWORD size = FormatMessageA(FORMAT_MESSAGE_FROM_SYSTEM  | FORMAT_MESSAGE_IGNORE_INSERTS | FORMAT_MESSAGE_ALLOCATE_BUFFER,
									  NULL, // (not used with FORMAT_MESSAGE_FROM_SYSTEM)
									  dwErrorCode,
									  MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
									  reinterpret_cast<LPSTR>(&messageBuffer),
									  0,
									  NULL);
	if (!size) {
		return std::format("Unknown error code: {}", dwErrorCode);
	}

	defer {
		LocalFree(messageBuffer);
	};

	return { messageBuffer, size };
}

Assembly::~Assembly() {
	if (_handle) {
		[[maybe_unused]] BOOL success = FreeLibrary(static_cast<HMODULE>(_handle));
#if PLUGIFY_LOGGING
		if (!success) {
			PL_LOG_VERBOSE("Assembly::~Assembly() - '{}': {}", _path.string(), GetErrorMessage());
		}
#endif // PLUGIFY_LOGGING
		_handle = nullptr;
	}
}

static std::wstring GetModulePath(HMODULE hModule) {
	std::wstring path(MAX_PATH, L'\0');
	while (true) {
		size_t len = ::GetModuleFileNameW(hModule, path.data(), static_cast<DWORD>(path.length()));
		if (len == 0) {
			path.clear();
			break;
		}

		if (len < path.length()) {
			path.resize(len);
			break;
		} else {
			path.resize(path.length() * 2);
		}
	}

	return path;
}

bool Assembly::InitFromName(std::string_view name, LoadFlag flags, const SearchDirs& searchDirs, bool sections, bool extension) {
	if (_handle)
		return false;

	if (name.empty())
		return false;

	std::filesystem::path fullName = PLUGIFY_LIBRARY_PREFIX;
	fullName += name;
	if (!extension && !fullName.has_extension())
		fullName += PLUGIFY_LIBRARY_SUFFIX;

	HMODULE handle = ::GetModuleHandleW(fullName.c_str());
	if (!handle)
		return false;

	std::wstring path = ::GetModulePath(handle);
	if (path.empty())
		return false;

	if (!Init(path, flags, searchDirs, sections))
		return false;

	return true;
}

bool Assembly::InitFromMemory(MemAddr memory, LoadFlag flags, const SearchDirs& searchDirs, bool sections) {
	if (_handle)
		return false;

	if (!memory)
		return false;

	MEMORY_BASIC_INFORMATION mbi;
	if (!VirtualQuery(memory, &mbi, sizeof(mbi)))
		return false;

	std::wstring path = ::GetModulePath(reinterpret_cast<HMODULE>(mbi.AllocationBase));
	if (path.empty())
		return false;

	if (!Init(path, flags, searchDirs, sections))
		return false;

	return true;
}

bool Assembly::InitFromHandle(Handle handle, LoadFlag flags, const SearchDirs& searchDirs, bool sections) {
	if (_handle)
		return false;

	if (!handle)
		return false;

	std::wstring path = ::GetModulePath(reinterpret_cast<HMODULE>(static_cast<void*>(handle)));
	if (path.empty())
		return false;

	if (!Init(path, flags, searchDirs, sections))
		return false;

	return true;
}

bool Assembly::Init(const std::filesystem::path& path, LoadFlag flags, const SearchDirs& searchDirs, bool sections) {
	if (!IsExist(path)) {
		return false;
	}

	std::vector<DLL_DIRECTORY_COOKIE> dirCookies;
	dirCookies.reserve(searchDirs.size());
	for (const auto& directory : searchDirs) {
		DLL_DIRECTORY_COOKIE cookie = AddDllDirectory(directory.c_str());
		if (cookie == nullptr)
			continue;
		dirCookies.push_back(cookie);
	}

	defer {
		for (auto& cookie : dirCookies)
			RemoveDllDirectory(cookie);
	};

	HMODULE hModule = LoadLibraryExW(path.c_str(), nullptr, TranslateLoading(flags));
	if (!hModule) {
		_error = GetErrorMessage();
		return false;
	}

	_handle = hModule;
	_path = std::move(path);

	if (flags & LoadFlag::PinInMemory) {
		HMODULE hPinHandle = NULL;
		GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS | GET_MODULE_HANDLE_EX_FLAG_PIN, reinterpret_cast<LPCWSTR>(hModule), &hPinHandle);
	}

	if (sections) {
		LoadSections();
	}

	return true;
}

bool Assembly::LoadSections() {
	IMAGE_DOS_HEADER* pDOSHeader = reinterpret_cast<IMAGE_DOS_HEADER*>(_handle);
	IMAGE_NT_HEADERS* pNTHeaders = reinterpret_cast<IMAGE_NT_HEADERS*>(reinterpret_cast<uintptr_t>(_handle) + pDOSHeader->e_lfanew);
	/*
		IMAGE_FILE_HEADER* pFileHeader = &pNTHeaders->OptionalHeader;
		IMAGE_OPTIONAL_HEADER* pOptionalHeader = &pNTHeaders->OptionalHeader;;

		if (pDOSHeader->e_magic != IMAGE_DOS_SIGNATURE || pNTHeaders->Signature != IMAGE_NT_SIGNATURE || pOptionalHeader->Magic != PE_NT_OPTIONAL_HDR_MAGIC) {
			_error = "Not a valid DLL file.";
			return false;
		}

		if (pFileHeader->Machine != PE_FILE_MACHINE) {
			_error = "Not a valid DLL file architecture.";
			return false;
		}

		if ((pFileHeader->Characteristics & IMAGE_FILE_DLL) == 0) {
			_error = "DLL file must be a dynamic library.";
			return false;
		}
	*/
	const IMAGE_SECTION_HEADER* hSection = IMAGE_FIRST_SECTION(pNTHeaders);// Get first image section.

	// Loop through the sections
	for (WORD i = 0; i < pNTHeaders->FileHeader.NumberOfSections; ++i) {
		const IMAGE_SECTION_HEADER& hCurrentSection = hSection[i]; // Get current section.
		_sections.emplace_back(
			reinterpret_cast<const char*>(hCurrentSection.Name),
			reinterpret_cast<uintptr_t>(_handle) + hCurrentSection.VirtualAddress,
			hCurrentSection.SizeOfRawData);// Push back a struct with the section data.
	}

	return true;
}

MemAddr Assembly::GetVirtualTableByName(std::string_view tableName, bool decorated) const {
	if (tableName.empty())
		return nullptr;

	Assembly::Section runTimeData = GetSectionByName(".data"), readOnlyData = GetSectionByName(".rdata");
	if (!runTimeData || !readOnlyData)
		return nullptr;

	std::string decoratedTableName(decorated ? tableName : ".?AV" + std::string(tableName) + "@@");
	std::string mask(decoratedTableName.length() + 1, 'x');

	MemAddr typemanifestName = FindPattern(decoratedTableName.data(), mask, nullptr, &runTimeData);
	if (!typemanifestName)
		return nullptr;

	MemAddr rttiTypemanifest = typemanifestName.Offset(-0x10);
	const uintptr_t rttiTDRva = rttiTypemanifest - GetBase();// The RTTI gets referenced by a 4-Byte RVA address. We need to scan for that address.

	MemAddr reference; // Get reference typeinfo in vtable
	while ((reference = FindPattern(&rttiTDRva, "xxxx", reference, &readOnlyData))) {
		// Check if we got a RTTI Object Locator for this reference by checking if -0xC is 1, which is the 'signature' field which is always 1 on x64.
		// Check that offset of this vtable is 0
		if (reference.Offset(-0xC).GetValue<int32_t>() == 1 && reference.Offset(-0x8).GetValue<int32_t>() == 0) {
			MemAddr referenceOffset = reference.Offset(-0xC);
			MemAddr rttiCompleteObjectLocator = FindPattern(&referenceOffset, "xxxxxxxx", nullptr, &readOnlyData);
			if (rttiCompleteObjectLocator)
				return rttiCompleteObjectLocator.Offset(0x8);
		}

		reference.OffsetSelf(0x4);
	}

	return nullptr;
}

MemAddr Assembly::GetFunctionByName(std::string_view functionName) const noexcept {
	if (!_handle)
		return nullptr;

	if (functionName.empty())
		return nullptr;

	FARPROC pAddress = GetProcAddress(static_cast<HMODULE>(_handle), functionName.data());
#if PLUGIFY_LOGGING
	if (!pAddress) {
		PL_LOG_VERBOSE("Assembly::GetFunctionByName() - '{}': {}", functionName, GetErrorMessage());
	}
#endif // PLUGIFY_LOGGING
	return pAddress;
}

plugify::MemAddr Assembly::GetBase() const noexcept {
	return _handle;
}

namespace plugify {
	int TranslateLoading(LoadFlag flags) noexcept {
		int winFlags = 0;
		if (flags & LoadFlag::DontResolveDllReferences) winFlags |= DONT_RESOLVE_DLL_REFERENCES;
		if (flags & LoadFlag::AlteredSearchPath) winFlags |= LOAD_WITH_ALTERED_SEARCH_PATH;
		if (flags & LoadFlag::AsDatafile) winFlags |= LOAD_LIBRARY_AS_DATAFILE;
		if (flags & LoadFlag::AsDatafileExclusive) winFlags |= LOAD_LIBRARY_AS_DATAFILE_EXCLUSIVE;
		if (flags & LoadFlag::AsImageResource) winFlags |= LOAD_LIBRARY_AS_IMAGE_RESOURCE;
		if (flags & LoadFlag::SearchApplicationDir) winFlags |= LOAD_LIBRARY_SEARCH_APPLICATION_DIR;
		if (flags & LoadFlag::SearchDefaultDirs) winFlags |= LOAD_LIBRARY_SEARCH_DEFAULT_DIRS;
		if (flags & LoadFlag::SearchDllLoadDir) winFlags |= LOAD_LIBRARY_SEARCH_DLL_LOAD_DIR;
		if (flags & LoadFlag::SearchSystem32) winFlags |= LOAD_LIBRARY_SEARCH_SYSTEM32;
		if (flags & LoadFlag::SearchUserDirs) winFlags |= LOAD_LIBRARY_SEARCH_USER_DIRS;
		if (flags & LoadFlag::RequireSignedTarget) winFlags |= LOAD_LIBRARY_REQUIRE_SIGNED_TARGET;
		if (flags & LoadFlag::IgnoreAuthzLevel) winFlags |= LOAD_IGNORE_CODE_AUTHZ_LEVEL;
#ifdef LOAD_LIBRARY_SAFE_CURRENT_DIRS
		if (flags & LoadFlag::SafeCurrentDirs) winFlags |= LOAD_LIBRARY_SAFE_CURRENT_DIRS;
#endif // LOAD_LIBRARY_SAFE_CURRENT_DIRS
		return winFlags;
	}

	LoadFlag TranslateLoading(int flags) noexcept {
		LoadFlag loadFlags = LoadFlag::Default;
		if (flags & DONT_RESOLVE_DLL_REFERENCES) loadFlags = loadFlags | LoadFlag::DontResolveDllReferences;
		if (flags & LOAD_WITH_ALTERED_SEARCH_PATH) loadFlags = loadFlags | LoadFlag::AlteredSearchPath;
		if (flags & LOAD_LIBRARY_AS_DATAFILE) loadFlags = loadFlags | LoadFlag::AsDatafile;
		if (flags & LOAD_LIBRARY_AS_DATAFILE_EXCLUSIVE) loadFlags = loadFlags | LoadFlag::AsDatafileExclusive;
		if (flags & LOAD_LIBRARY_AS_IMAGE_RESOURCE) loadFlags = loadFlags | LoadFlag::AsImageResource;
		if (flags & LOAD_LIBRARY_SEARCH_APPLICATION_DIR) loadFlags = loadFlags | LoadFlag::SearchApplicationDir;
		if (flags & LOAD_LIBRARY_SEARCH_DEFAULT_DIRS) loadFlags = loadFlags | LoadFlag::SearchDefaultDirs;
		if (flags & LOAD_LIBRARY_SEARCH_DLL_LOAD_DIR) loadFlags = loadFlags | LoadFlag::SearchDllLoadDir;
		if (flags & LOAD_LIBRARY_SEARCH_SYSTEM32) loadFlags = loadFlags | LoadFlag::SearchSystem32;
		if (flags & LOAD_LIBRARY_SEARCH_USER_DIRS) loadFlags = loadFlags | LoadFlag::SearchUserDirs;
		if (flags & LOAD_LIBRARY_REQUIRE_SIGNED_TARGET) loadFlags = loadFlags | LoadFlag::RequireSignedTarget;
		if (flags & LOAD_IGNORE_CODE_AUTHZ_LEVEL) loadFlags = loadFlags | LoadFlag::IgnoreAuthzLevel;
#ifdef LOAD_LIBRARY_SAFE_CURRENT_DIRS
		if (flags & LOAD_LIBRARY_SAFE_CURRENT_DIRS) loadFlags = loadFlags | LoadFlag::SafeCurrentDirs;
#endif // LOAD_LIBRARY_SAFE_CURRENT_DIRS
		return loadFlags;
	}
}

#endif // PLUGIFY_PLATFORM_WINDOWS
