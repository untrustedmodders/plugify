## CMake
|Feature|New in|
|---|---|
|C++20|3.12|
|C11|3.1|
|**Optional**||
|Presets v4|3.23|