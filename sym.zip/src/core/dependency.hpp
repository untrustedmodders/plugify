#pragma once

#include <plugify/api/version.hpp>

namespace plugify {
	struct Dependency {
		std::string name;
		std::optional<std::vector<Constraint>> constraints;  // ANDed together
		std::optional<bool> optional;

		std::optional<Constraint> ConflictsWith(const Version& version) const {
			if (constraints) {
				for (const auto& constraint : *constraints) {
					if (!constraint.IsSatisfiedBy(version)) {
						return constraint;
					}
				}
			}
			return std::nullopt;
		}

		std::vector<Constraint> GetFailedConstraints(const Version& version) const {
			std::vector<Constraint> failed;
			if (constraints) {
				for (const auto& constraint : *constraints) {
					if (!constraint.IsSatisfiedBy(version)) {
						failed.push_back(constraint);
					}
				}
			}
			return failed;
		}

		bool operator==(const Dependency& dependency) const noexcept = default;
	};
}
